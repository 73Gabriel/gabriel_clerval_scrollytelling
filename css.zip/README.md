# Projet Scrollytelling Vers l'infini et l'espace!
## Projet scolaire dans le cadre du cours [Optimisation Web - Projet Scrollytelling](https://tim-montmorency.com/timdoc/582-424MO/projet-scrollytelling/)
# Équipe
* Clerval Gabriel
* Dominic Yale
* William Rathier Mailly
 # Conception
* Clerval Gabriel
 # Technologies
* HTML
* CSS
* JavaScript
* [Librairie d'animation GSAP](https://gsap.com)
* [Plugiciel ScrollTrigger](https://gsap.com/docs/v3/Plugins/ScrollTrigger/)
  
